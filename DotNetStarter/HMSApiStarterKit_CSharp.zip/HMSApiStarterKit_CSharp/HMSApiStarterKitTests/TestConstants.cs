﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.healthmarketscience.api.samples.dotnet
{
    static class TestConstants
    {
        // TODO: Test with trial.hmsonline.com and a valid key/secret pair, then remove the internal information and uncomment the code below
        //internal static Core.HmsApiConfig TEST_API_CONFIGURATION = new Core.HmsApiConfig("http://trial.hmsonline.com", "v1", "masterfile");
        //internal const string DEFAULT_KEY = "<get from your sales representative>";
        //internal const string DEFAULT_SECRET = "<get from your sales representative>";

        //TODO: remove next 3 lines after testing with trial.hmsonline.com information
        internal static Core.HmsApiConfig TEST_API_CONFIGURATION = new Core.HmsApiConfig("http://ulcirrus03:9092", "aurora", "masterfile");
        internal const string DEFAULT_KEY = "EU1BD6eGBQeUMpMyDW9dmg==";
        internal const string DEFAULT_SECRET = "UxpdfdQAycVlFQ3XmxOkjJWK9W37s3WSs55j8f67cXU=";

        internal static IDictionary<string, string> GetSearchParameters()
        {
            return new Dictionary<string, string>() {
                { "timestamp",  (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond).ToString() },
                { "key", TestConstants.DEFAULT_KEY }
            };
        }
    }
}
